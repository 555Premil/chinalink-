import os
import sqlite3
import logging
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
)
from telegram.constants import ParseMode
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler, MessageHandler,
    ContextTypes, ConversationHandler, filters,
)

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_CHAT_ID = os.getenv("ADMIN_CHAT_ID", "").strip()
DB_PATH = os.getenv("DB_PATH", "chinalink.db")

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is missing. Put it in .env")

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("chinalink")

# Conversation states
(
    SERVICE_DETAILS,
    OVERSTAY_NAME,
    OVERSTAY_NATIONALITY,
    OVERSTAY_PASSPORT,
    OVERSTAY_EXPIRY,
    OVERSTAY_LOCATION,
    OVERSTAY_DOCS,
    RENTAL_LOCATION,
    RENTAL_DATES,
    RENTAL_DAYS,
    RENTAL_TYPE,
    RENTAL_DRIVER,
    RENTAL_DONE,
    HOUSING_LOCATION,
    HOUSING_BUDGET,
    HOUSING_DATE,
    HOUSING_PEOPLE,
    HOUSING_DONE,
    GENERAL_HELP,
) = range(19)

STATUS_LABELS = {
    "received": "🟡 收到申请 / Received",
    "processing": "🔵 处理中 / Processing",
    "waiting_docs": "🟣 等待客户资料 / Waiting for documents",
    "external": "🟠 等待政府/第三方处理 / Waiting for external processing",
    "completed": "🟢 已完成 / Completed",
}

SERVICE_NAMES = {
    "visa_tourist": "旅游签证 / Tourist Visa",
    "visa_business": "商务签证 / Business Visa",
    "visa_work": "工作签证 / Work Visa",
    "visa_extension": "签证延期 / Visa Extension",
    "visa_overstay": "签证逾期 / Visa Overstay",
    "visa_other": "其他签证问题 / Other Visa",
    "company": "公司及商务服务 / Company & Business",
    "vehicle": "租车服务 / Vehicle Rental",
    "housing": "公寓/住宿 / Accommodation",
    "documents": "文件服务 / Documents",
    "general": "其他帮助 / General Help",
    "emergency": "紧急帮助 / Urgent Help",
}

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS cases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            username TEXT,
            full_name TEXT,
            service TEXT NOT NULL,
            details TEXT,
            status TEXT NOT NULL DEFAULT 'received',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            case_id INTEGER NOT NULL,
            telegram_file_id TEXT NOT NULL,
            file_type TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(case_id) REFERENCES cases(id)
        )
    """)
    conn.commit()
    return conn

def create_case(user, service, details):
    now = datetime.utcnow().isoformat(timespec="seconds") + "Z"
    conn = db()
    cur = conn.execute(
        """INSERT INTO cases
        (user_id, username, full_name, service, details, status, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, 'received', ?, ?)""",
        (
            user.id,
            user.username or "",
            user.full_name or "",
            service,
            details,
            now,
            now,
        ),
    )
    conn.commit()
    case_id = cur.lastrowid
    conn.close()
    return case_id

def add_document(case_id, file_id, file_type):
    conn = db()
    conn.execute(
        "INSERT INTO documents(case_id, telegram_file_id, file_type, created_at) VALUES (?, ?, ?, ?)",
        (case_id, file_id, file_type, datetime.utcnow().isoformat(timespec="seconds") + "Z"),
    )
    conn.commit()
    conn.close()

def get_case(case_id):
    conn = db()
    row = conn.execute("SELECT * FROM cases WHERE id=?", (case_id,)).fetchone()
    conn.close()
    return row

def get_user_cases(user_id):
    conn = db()
    rows = conn.execute(
        "SELECT * FROM cases WHERE user_id=? ORDER BY id DESC LIMIT 10", (user_id,)
    ).fetchall()
    conn.close()
    return rows

def update_status(case_id, status):
    conn = db()
    conn.execute(
        "UPDATE cases SET status=?, updated_at=? WHERE id=?",
        (status, datetime.utcnow().isoformat(timespec="seconds") + "Z", case_id),
    )
    conn.commit()
    conn.close()

def main_menu():
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🛂 签证服务 / Visa Services", callback_data="menu:visa")],
        [InlineKeyboardButton("⚠️ 签证逾期 / Overstay", callback_data="menu:overstay")],
        [InlineKeyboardButton("🏢 公司服务 / Business", callback_data="menu:company"),
         InlineKeyboardButton("🚗 租车 / Vehicle", callback_data="menu:vehicle")],
        [InlineKeyboardButton("🏠 公寓/住宿 / Accommodation", callback_data="menu:housing"),
         InlineKeyboardButton("📄 文件服务 / Documents", callback_data="menu:documents")],
        [InlineKeyboardButton("🆘 我需要帮助 / I Need Help", callback_data="menu:help"),
         InlineKeyboardButton("🔎 我的申请 / My Cases", callback_data="menu:cases")],
        [InlineKeyboardButton("👨‍💼 联系工作人员 / Contact Staff", callback_data="menu:staff")],
    ])

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    text = (
        "🇨🇳🇱🇰 <b>欢迎来到 ChinaLink Sri Lanka</b>\n\n"
        "在斯里兰卡遇到签证、逾期、公司、租车、住宿或其他问题？\n\n"
        "<b>我们帮您解决。</b>\n\n"
        "⭐ <b>先办事，后付款</b>\n"
        "First Do. Later Pay.\n\n"
        "中文服务｜专人协助｜一站式服务"
    )
    await update.effective_message.reply_text(
        text, parse_mode=ParseMode.HTML, reply_markup=main_menu()
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(
        "请选择您需要的服务，或直接输入您的问题。/ Please choose a service or describe your problem.",
        reply_markup=main_menu(),
    )

async def menu_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    action = q.data.split(":", 1)[1]

    if action == "visa":
        kb = [
            [("🇱🇰 旅游签证 / Tourist Visa", "visa_tourist")],
            [("💼 商务签证 / Business Visa", "visa_business")],
            [("👷 工作签证 / Work Visa", "visa_work")],
            [("🔄 签证延期 / Visa Extension", "visa_extension")],
            [("⚠️ 签证逾期 / Overstay", "visa_overstay")],
            [("❓ 其他问题 / Other", "visa_other")],
            [("🔙 返回主页 / Back", "back")],
        ]
        await q.edit_message_text(
            "<b>🛂 签证服务 / Visa Services</b>\n\n您需要什么签证服务？\nWhat visa service do you need?",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(a, callback_data=f"service:{b}")] for a,b in kb])
        )
    elif action == "overstay":
        return await start_overstay(update, context)
    elif action == "company":
        await q.edit_message_text(
            "<b>🏢 公司及商务服务 / Company & Business</b>\n\n"
            "我们可以协助您处理公司注册、公司文件、许可证协助、翻译及其他商务事务。\n\n"
            "请直接描述您的需求，工作人员会联系您。",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📩 提交需求 / Submit Request", callback_data="start:company")],
                [InlineKeyboardButton("🔙 返回主页 / Back", callback_data="back")],
            ])
        )
    elif action == "vehicle":
        return await start_vehicle(update, context)
    elif action == "housing":
        return await start_housing(update, context)
    elif action == "documents":
        await q.edit_message_text(
            "<b>📄 文件服务 / Documents</b>\n\n"
            "您可以发送文件、照片或说明您的需求。\n"
            "You can send a document/photo or describe what you need.\n\n"
            "工作人员会查看后联系您。",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📩 提交需求 / Submit Request", callback_data="start:documents")],
                [InlineKeyboardButton("🔙 返回主页 / Back", callback_data="back")],
            ])
        )
    elif action == "help":
        context.user_data["general_help"] = True
        await q.edit_message_text(
            "🆘 <b>需要帮助？ / Need Help?</b>\n\n"
            "没关系，直接用中文或英文告诉我们您的问题。\n"
            "Just describe your problem in Chinese or English.\n\n"
            "例如：\n“My visa expired yesterday.”\n“我想在科伦坡租公寓。”",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 返回主页 / Back", callback_data="back")]])
        )
        return GENERAL_HELP
    elif action == "cases":
        rows = get_user_cases(update.effective_user.id)
        if not rows:
            txt = "🔎 <b>我的申请 / My Cases</b>\n\n目前没有申请记录。"
        else:
            lines = ["🔎 <b>我的申请 / My Cases</b>\n"]
            for r in rows:
                lines.append(
                    f"#{r['id']} — {SERVICE_NAMES.get(r['service'], r['service'])}\n"
                    f"{STATUS_LABELS.get(r['status'], r['status'])}\n"
                )
            txt = "\n".join(lines)
        await q.edit_message_text(
            txt, parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 返回主页 / Back", callback_data="back")]])
        )
    elif action == "staff":
        await q.edit_message_text(
            "👨‍💼 <b>联系工作人员 / Contact Staff</b>\n\n"
            "请点击下面的按钮或直接发送您的问题。\n\n"
            "中文服务 🇨🇳\n"
            "⭐ 先办事，后付款\n"
            "First Do. Later Pay.",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🆘 发送我的问题 / Send My Problem", callback_data="start:general")],
                [InlineKeyboardButton("🔙 返回主页 / Back", callback_data="back")],
            ])
        )

async def back(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()
    await update.callback_query.edit_message_text(
        "🇨🇳🇱🇰 <b>ChinaLink Sri Lanka</b>\n\n⭐ <b>先办事，后付款</b>\nFirst Do. Later Pay.",
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu(),
    )
    context.user_data.clear()
    return ConversationHandler.END

async def service_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    service = q.data.split(":", 1)[1]
    if service == "visa_overstay":
        return await start_overstay(update, context)

    context.user_data["service"] = service
    await q.edit_message_text(
        f"✅ {SERVICE_NAMES[service]}\n\n"
        "请告诉我们您的具体需求。\n"
        "Please describe what you need. You can write in Chinese or English.\n\n"
        "例如 / Example: “I need help applying for a business visa.”",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🔙 返回主页 / Back", callback_data="back")]
        ]),
    )
    return SERVICE_DETAILS

async def save_simple_service(update: Update, context: ContextTypes.DEFAULT_TYPE):
    service = context.user_data.get("service", "general")
    details = update.effective_message.text or ""
    case_id = create_case(update.effective_user, service, details)
    await notify_admin_new_case(context, case_id)
    await update.effective_message.reply_text(
        f"✅ <b>已收到！/ Received!</b>\n\n"
        f"案件编号 / Case ID: <b>#{case_id}</b>\n"
        f"服务 / Service: {SERVICE_NAMES.get(service, service)}\n\n"
        "我们的工作人员会联系您。\n"
        "Our staff will contact you.\n\n"
        "⭐ <b>先办事，后付款</b>\n"
        "First Do. Later Pay.",
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu(),
    )
    context.user_data.clear()
    return ConversationHandler.END

async def start_overstay(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(
            "⚠️ <b>签证逾期问题 / Visa Overstay</b>\n\n"
            "如果您的斯里兰卡签证已经过期，请告诉我们您的情况。\n"
            "我们可以协助您了解手续、相关费用及下一步流程。\n\n"
            "<i>政府罚款、签证费用及其他官方费用可能另行产生。</i>\n\n"
            "⭐ <b>先处理，后付款</b>",
            parse_mode=ParseMode.HTML,
        )
        await update.effective_message.reply_text("1/6 请告诉我们您的姓名 / Full name:")
    else:
        await update.effective_message.reply_text("1/6 请告诉我们您的姓名 / Full name:")
    context.user_data.clear()
    context.user_data["service"] = "visa_overstay"
    return OVERSTAY_NAME

async def overstay_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["overstay_name"] = update.effective_message.text
    await update.effective_message.reply_text("2/6 国籍 / Nationality:")
    return OVERSTAY_NATIONALITY

async def overstay_nationality(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["overstay_nationality"] = update.effective_message.text
    await update.effective_message.reply_text("3/6 护照号码 / Passport number:")
    return OVERSTAY_PASSPORT

async def overstay_passport(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["overstay_passport"] = update.effective_message.text
    await update.effective_message.reply_text("4/6 签证到期日期 / Visa expiry date:")
    return OVERSTAY_EXPIRY

async def overstay_expiry(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["overstay_expiry"] = update.effective_message.text
    await update.effective_message.reply_text("5/6 您目前在哪里？ / Where are you currently located?")
    return OVERSTAY_LOCATION

async def overstay_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["overstay_location"] = update.effective_message.text
    await update.effective_message.reply_text(
        "6/6 请上传护照和签证页面 / Upload your passport and visa page.\n\n"
        "您也可以发送照片。如果暂时没有文件，请发送“稍后 / Later”。"
    )
    return OVERSTAY_DOCS

async def overstay_docs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = context.user_data
    details = (
        f"Name: {data.get('overstay_name')}\n"
        f"Nationality: {data.get('overstay_nationality')}\n"
        f"Passport: {data.get('overstay_passport')}\n"
        f"Visa expiry: {data.get('overstay_expiry')}\n"
        f"Location: {data.get('overstay_location')}\n"
        f"Documents: {'uploaded' if update.effective_message.document or update.effective_message.photo else 'not uploaded'}"
    )
    case_id = create_case(update.effective_user, "visa_overstay", details)

    if update.effective_message.document:
        add_document(case_id, update.effective_message.document.file_id, "document")
    elif update.effective_message.photo:
        add_document(case_id, update.effective_message.photo[-1].file_id, "photo")

    await notify_admin_new_case(context, case_id)
    await update.effective_message.reply_text(
        f"✅ <b>我们已经收到您的资料。</b>\n\n"
        f"案件编号 / Case ID: <b>#{case_id}</b>\n"
        f"状态 / Status: {STATUS_LABELS['received']}\n\n"
        "工作人员会查看您的情况并联系您。\n\n"
        "⭐ <b>先办事，后付款</b>",
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu(),
    )
    context.user_data.clear()
    return ConversationHandler.END

async def start_vehicle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(
            "🚗 <b>租车服务 / Vehicle Rental</b>\n\n您需要什么？",
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🚘 汽车 / Car", callback_data="vehicle_type:car"),
                 InlineKeyboardButton("🚙 SUV", callback_data="vehicle_type:suv")],
                [InlineKeyboardButton("👨‍✈️ 汽车 + 司机 / Car + Driver", callback_data="vehicle_type:driver")],
                [InlineKeyboardButton("📅 长期租车 / Long-term", callback_data="vehicle_type:long")],
                [InlineKeyboardButton("✈️ 机场接送 / Airport Transfer", callback_data="vehicle_type:airport")],
                [InlineKeyboardButton("🔙 返回主页 / Back", callback_data="back")],
            ])
        )
    else:
        await update.effective_message.reply_text("🚗 请告诉我们您的租车需求 / Tell us your vehicle needs:")
    return RENTAL_TYPE

async def vehicle_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    context.user_data["vehicle_type"] = q.data.split(":", 1)[1]
    await q.edit_message_text("📍 您需要在哪里取车？ / Where do you need the vehicle?")
    return RENTAL_LOCATION

async def vehicle_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["vehicle_location"] = update.effective_message.text
    await update.effective_message.reply_text("📅 租车日期 / Rental dates:")
    return RENTAL_DATES

async def vehicle_dates(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["vehicle_dates"] = update.effective_message.text
    await update.effective_message.reply_text("📅 需要几天？ / How many days?")
    return RENTAL_DAYS

async def vehicle_days(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["vehicle_days"] = update.effective_message.text
    await update.effective_message.reply_text("👨‍✈️ 是否需要司机？ / Do you need a driver? (Yes/No)")
    return RENTAL_DRIVER

async def vehicle_driver(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["vehicle_driver"] = update.effective_message.text
    d = context.user_data
    details = "\n".join(f"{k}: {v}" for k,v in d.items())
    case_id = create_case(update.effective_user, "vehicle", details)
    await notify_admin_new_case(context, case_id)
    await update.effective_message.reply_text(
        f"✅ 租车需求已收到！/ Request received!\n\n案件编号 / Case ID: <b>#{case_id}</b>\n\n"
        "我们会联系您确认车辆和安排。\n⭐ <b>先办事，后付款</b>",
        parse_mode=ParseMode.HTML, reply_markup=main_menu()
    )
    context.user_data.clear()
    return ConversationHandler.END

async def start_housing(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(
            "🏠 <b>住宿服务 / Accommodation</b>\n\n"
            "我们可以协助寻找公寓、房屋、酒店或长期住宿。",
            parse_mode=ParseMode.HTML,
        )
        await update.effective_message.reply_text("1/4 📍 您想住在哪里？ / Preferred location?")
    else:
        await update.effective_message.reply_text("1/4 📍 您想住在哪里？ / Preferred location?")
    context.user_data.clear()
    context.user_data["service"] = "housing"
    return HOUSING_LOCATION

async def housing_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["housing_location"] = update.effective_message.text
    await update.effective_message.reply_text("2/4 💰 预算是多少？ / What is your budget?")
    return HOUSING_BUDGET

async def housing_budget(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["housing_budget"] = update.effective_message.text
    await update.effective_message.reply_text("3/4 📅 入住日期？ / Move-in date?")
    return HOUSING_DATE

async def housing_date(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["housing_date"] = update.effective_message.text
    await update.effective_message.reply_text("4/4 👥 几个人？ / How many people?")
    return HOUSING_PEOPLE

async def housing_people(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["housing_people"] = update.effective_message.text
    d = context.user_data
    details = "\n".join(f"{k}: {v}" for k,v in d.items())
    case_id = create_case(update.effective_user, "housing", details)
    await notify_admin_new_case(context, case_id)
    await update.effective_message.reply_text(
        f"✅ 住宿需求已收到！/ Request received!\n\n案件编号 / Case ID: <b>#{case_id}</b>\n\n"
        "我们会根据您的要求寻找合适的选择。\n⭐ <b>先办事，后付款</b>",
        parse_mode=ParseMode.HTML, reply_markup=main_menu()
    )
    context.user_data.clear()
    return ConversationHandler.END

async def general_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    details = update.effective_message.text or ""
    case_id = create_case(update.effective_user, "general", details)
    await notify_admin_new_case(context, case_id)
    await update.effective_message.reply_text(
        f"✅ 已收到您的问题 / We received your request.\n\n"
        f"案件编号 / Case ID: <b>#{case_id}</b>\n\n"
        "工作人员会尽快联系您。\n⭐ <b>先办事，后付款</b>",
        parse_mode=ParseMode.HTML, reply_markup=main_menu()
    )
    context.user_data.clear()
    return ConversationHandler.END

async def notify_admin_new_case(context, case_id):
    if not ADMIN_CHAT_ID:
        log.warning("ADMIN_CHAT_ID not configured; case %s was saved but not forwarded.", case_id)
        return
    row = get_case(case_id)
    text = (
        "🔴 <b>NEW CASE / 新案件</b>\n\n"
        f"<b>#{row['id']}</b>\n"
        f"👤 {row['full_name']} (@{row['username'] or 'no_username'})\n"
        f"🆔 Telegram ID: <code>{row['user_id']}</code>\n"
        f"📌 {SERVICE_NAMES.get(row['service'], row['service'])}\n"
        f"🟡 {STATUS_LABELS['received']}\n\n"
        f"<b>Details:</b>\n{row['details'][:3500]}"
    )
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔵 Processing", callback_data=f"admin:{case_id}:processing"),
         InlineKeyboardButton("🟣 Need Docs", callback_data=f"admin:{case_id}:waiting_docs")],
        [InlineKeyboardButton("🟠 External", callback_data=f"admin:{case_id}:external"),
         InlineKeyboardButton("🟢 Completed", callback_data=f"admin:{case_id}:completed")],
        [InlineKeyboardButton("💬 Message Customer", callback_data=f"adminmsg:{case_id}")],
    ])
    try:
        await context.bot.send_message(
            chat_id=int(ADMIN_CHAT_ID), text=text,
            parse_mode=ParseMode.HTML, reply_markup=keyboard
        )
    except Exception:
        log.exception("Could not notify admin")

async def admin_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if str(q.from_user.id) != ADMIN_CHAT_ID:
        return
    _, case_id, status = q.data.split(":")
    update_status(int(case_id), status)
    row = get_case(int(case_id))
    await q.edit_message_reply_markup(
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton(f"Current: {STATUS_LABELS[status]}", callback_data="noop")],
            [InlineKeyboardButton("💬 Message Customer", callback_data=f"adminmsg:{case_id}")],
        ])
    )
    try:
        await context.bot.send_message(
            chat_id=row["user_id"],
            text=(
                f"🔔 <b>申请状态更新 / Status Updated</b>\n\n"
                f"案件 / Case: <b>#{case_id}</b>\n"
                f"{STATUS_LABELS[status]}"
            ),
            parse_mode=ParseMode.HTML,
        )
    except Exception:
        log.exception("Could not notify customer")

async def noop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.answer()

async def admin_message_prompt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if str(q.from_user.id) != ADMIN_CHAT_ID:
        return ConversationHandler.END
    case_id = int(q.data.split(":")[1])
    context.user_data["admin_message_case"] = case_id
    await q.message.reply_text(
        f"💬 Please send the message for case #{case_id}.\n"
        "Your next message will be forwarded to the customer."
    )
    return SERVICE_DETAILS

async def admin_message_send(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if str(update.effective_user.id) != ADMIN_CHAT_ID:
        return ConversationHandler.END
    case_id = context.user_data.get("admin_message_case")
    if not case_id:
        return ConversationHandler.END
    row = get_case(case_id)
    msg = update.effective_message.text or ""
    await context.bot.send_message(
        chat_id=row["user_id"],
        text=f"👨‍💼 <b>ChinaLink Staff</b>\n\n{msg}",
        parse_mode=ParseMode.HTML,
    )
    await update.effective_message.reply_text(f"✅ Message sent to case #{case_id}.")
    context.user_data.clear()
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.effective_message.reply_text("已取消 / Cancelled.", reply_markup=main_menu())
    return ConversationHandler.END

def build_app():
    db()

    app = Application.builder().token(BOT_TOKEN).concurrent_updates(False).build()

    # Main navigation
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))

    app.add_handler(CallbackQueryHandler(back, pattern=r"^back$"))
    app.add_handler(CallbackQueryHandler(menu_router, pattern=r"^menu:"))
    app.add_handler(CallbackQueryHandler(service_choice, pattern=r"^service:"))
    app.add_handler(CallbackQueryHandler(admin_status, pattern=r"^admin:\d+:(processing|waiting_docs|external|completed)$"))
    app.add_handler(CallbackQueryHandler(admin_message_prompt, pattern=r"^adminmsg:\d+$"))
    app.add_handler(CallbackQueryHandler(noop, pattern=r"^noop$"))

    # General simple service conversations
    simple_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(lambda u,c: service_choice(u,c), pattern=r"^service:(visa_tourist|visa_business|visa_work|visa_extension|visa_other)$")],
        states={SERVICE_DETAILS: [MessageHandler(filters.TEXT & ~filters.COMMAND, save_simple_service)]},
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True,
    )
    app.add_handler(simple_conv)

    # Overstay conversation
    overstay_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_overstay, pattern=r"^start:overstay$")],
        states={
            OVERSTAY_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, overstay_name)],
            OVERSTAY_NATIONALITY: [MessageHandler(filters.TEXT & ~filters.COMMAND, overstay_nationality)],
            OVERSTAY_PASSPORT: [MessageHandler(filters.TEXT & ~filters.COMMAND, overstay_passport)],
            OVERSTAY_EXPIRY: [MessageHandler(filters.TEXT & ~filters.COMMAND, overstay_expiry)],
            OVERSTAY_LOCATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, overstay_location)],
            OVERSTAY_DOCS: [
                MessageHandler(filters.Document.ALL | filters.PHOTO | (filters.TEXT & ~filters.COMMAND), overstay_docs)
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True,
    )
    app.add_handler(overstay_conv)

    # Vehicle conversation
    vehicle_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_vehicle, pattern=r"^start:vehicle$")],
        states={
            RENTAL_TYPE: [CallbackQueryHandler(vehicle_type, pattern=r"^vehicle_type:")],
            RENTAL_LOCATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, vehicle_location)],
            RENTAL_DATES: [MessageHandler(filters.TEXT & ~filters.COMMAND, vehicle_dates)],
            RENTAL_DAYS: [MessageHandler(filters.TEXT & ~filters.COMMAND, vehicle_days)],
            RENTAL_DRIVER: [MessageHandler(filters.TEXT & ~filters.COMMAND, vehicle_driver)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True,
    )
    app.add_handler(vehicle_conv)

    # Housing conversation
    housing_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_housing, pattern=r"^start:housing$")],
        states={
            HOUSING_LOCATION: [MessageHandler(filters.TEXT & ~filters.COMMAND, housing_location)],
            HOUSING_BUDGET: [MessageHandler(filters.TEXT & ~filters.COMMAND, housing_budget)],
            HOUSING_DATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, housing_date)],
            HOUSING_PEOPLE: [MessageHandler(filters.TEXT & ~filters.COMMAND, housing_people)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True,
    )
    app.add_handler(housing_conv)

    # General help conversation
    general_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(lambda u,c: (u.callback_query.answer(), u.callback_query.message.reply_text(
                "请直接描述您的问题 / Please describe your problem:"
            ), GENERAL_HELP)[-1], pattern=r"^start:(general|company|documents)$"),
            CallbackQueryHandler(lambda u,c: GENERAL_HELP, pattern=r"^menu:help$"),
        ],
        states={GENERAL_HELP: [MessageHandler(filters.TEXT & ~filters.COMMAND, general_help)]},
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True,
    )
    app.add_handler(general_conv)

    # Admin outbound message conversation
    admin_conv = ConversationHandler(
        entry_points=[],
        states={SERVICE_DETAILS: [MessageHandler(filters.TEXT & ~filters.COMMAND, admin_message_send)]},
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True,
    )
    # Admin message prompt is registered as a normal callback above; route its next text using this handler.
    app.add_handler(admin_conv)

    return app

if __name__ == "__main__":
    application = build_app()
    log.info("ChinaLink Telegram bot starting...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

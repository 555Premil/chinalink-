# ChinaLink Sri Lanka — Telegram Bot

A bilingual Chinese/English Telegram service bot for a Sri Lankan convenience/service business.

## Included

- Chinese/English main menu
- Visa services
- Visa overstay intake flow
- Company/business service requests
- Vehicle rental intake
- Accommodation intake
- Document-service requests
- General help
- Case IDs
- SQLite case database
- Customer status updates
- Admin notifications
- Admin status buttons
- Passport/document/photo intake for overstay cases
- "先办事，后付款 / First Do. Later Pay." positioning
- No payment collection

## Important

This bot is an intake and coordination system. It does not claim to be a government immigration system and should not promise a visa, bail, penalty waiver, or legal outcome. Government fees/penalties and third-party charges can be separate where applicable.

## Install

Python 3.10+ is recommended.

```bash
python -m venv .venv

# macOS/Linux
source .venv/bin/activate

# Windows
.venv\Scripts\activate

pip install -r requirements.txt
```

Copy `.env.example` to `.env` and fill in:

- `BOT_TOKEN`
- `ADMIN_CHAT_ID`

Then:

```bash
python bot.py
```

## Create the Telegram bot

1. Open Telegram and search for @BotFather.
2. Send `/newbot`.
3. Choose the bot name and username.
4. Copy the token into `.env`.
5. Start your new bot once from your own Telegram account.
6. Set `ADMIN_CHAT_ID` to your own numeric Telegram ID.
7. Restart the bot.

## Commands

- `/start` — open the main menu
- `/help` — show help
- `/cancel` — cancel an active request

## Production recommendations

Before accepting real passport documents:

- Run the bot on a secure server.
- Restrict access to the admin account.
- Add encryption/retention controls for sensitive documents.
- Add backups for the SQLite database or move to PostgreSQL.
- Add an explicit privacy notice and consent flow.
- Replace the simple admin chat with a proper secure dashboard.
- Add rate limiting and abuse protection.
- Keep your bot token secret.
